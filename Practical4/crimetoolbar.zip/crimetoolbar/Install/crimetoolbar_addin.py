import arcpy
import pythonaddins

class RiskButton(object):
    """Implementation for crimetoolbar_addin.RiskButton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Importing Trafford Model.", "Trafford Model")
        pythonaddins.GPToolDialog("Z:/GEOG5790/practical4/practical4.tbx", "TraffordModelScript")
        pass
