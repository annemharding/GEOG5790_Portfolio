import arcpy
import pythonaddins

class ExplosionButtonClass(object):
    """Implementation for addin_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Importing Explosions tool.", "explosions")
        object = pythonaddins.GPToolDialog("Z:\GEOG5790\practical2_scripts\WIP\Practical2.tbx", "explosionscript")
        arcpy.ExplosionModel_Practical1(buffer_distance, buffer_feature, intersect_features, output_intersect)
        pythonaddins.MessageBox("Explosions tool complete.", "explosions")
        pass

'''
class HelloButtonClass(object):
    """Implementation for addin_addin.hellobutton (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Appending 'Hello world.' to ComboBox.", "combobox")
        hellocombobox.items.append("Hello world.")
        qs = pythonaddins.MessageBox("Would you like to set the ComboBox value to 'Hello world.'?", "question", 4)
        if qs == 'Yes':
            hellocombobox.value = "Hello world."
            hellocombobox.refresh()
        pass

class HelloComboBoxClass(object):
    """Implementation for addin_addin.hellocombobox (ComboBox)"""
    def __init__(self):
        self.items = ["item1", "item2"]
        self.editable = True
        self.enabled = True
        self.dropdownWidth = 'WWWWWW'
        self.width = 'WWWWWW'
    def onSelChange(self, selection):
        pass
    def onEditChange(self, text):
        pass
    def onFocus(self, focused):
        pass
    def onEnter(self):
        pass
    def refresh(self):
        pass
'''
