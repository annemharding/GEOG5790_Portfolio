import arcpy
import pythonaddins

class ExplosionButtonClass(object):
    """Implementation for addin_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Importing Explosions tool.", "explosions")
        object = pythonaddins.GPToolDialog("Z:\GEOG5790\practical2_scripts\WIP\Practical2.tbx", "explosionscript")
        arcpy.ExplosionModel_Practical1(buffer_distance, buffer_feature, intersect_features, output_intersect)
        pythonaddins.MessageBox("Explosions tool complete.", "explosions")
        pass

