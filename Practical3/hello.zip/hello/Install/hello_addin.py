import arcpy
import pythonaddins

class ButtonClass1(object):
    """Implementation for hello_addin.button (Button)"""
    def __init__(self):
        self.enabled = True
        self.checked = False
    def onClick(self):
        pythonaddins.MessageBox("Appending 'Hello world.' to ComboBox.", "combobox")
        combobox.items.append("Hello world.")
        qs = pythonaddins.MessageBox("Would you like to set the ComboBox value to 'Hello world.'?", "question", 4)
        if qs == 'Yes':
            combobox.value = "Hello world."
            combobox.refresh()
        pass

class ComboBoxClass2(object):
    """Implementation for hello_addin.combobox (ComboBox)"""
    def __init__(self):
        self.items = ["item1", "item2"]
        self.editable = True
        self.enabled = True
        self.dropdownWidth = 'WWWWWW'
        self.width = 'WWWWWW'
    def onSelChange(self, selection):
        pass
    def onEditChange(self, text):
        pass
    def onFocus(self, focused):
        pass
    def onEnter(self):
        pass
    def refresh(self):
        pass
